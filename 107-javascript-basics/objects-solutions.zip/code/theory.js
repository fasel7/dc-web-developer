// Object literal
// Konstruktorfunktionen/Klassen
// Auf Properties zugreifen
// Punkt Notation
// Klammer Notation (dynamisch auslesen)
// Objekte bearbeiten
// Properties ändern
// Properties hinzufügen
// Properties löschen
// Überprüfen, ob ein Key/Property existiert
// Iterieren von Keys und Values
// this Keyword

const person = {
  firstName: 'Max',
  lastName: 'Mustermann',
  age: 20,
  height: 180,
  listProperties() {
    const arrayOfKeys = Object.keys(this);

    arrayOfKeys.forEach((key) => console.log(key, typeof this[key]));
  },
};

function listProperties(object) {
  const arrayOfKeys = Object.keys(object);

  arrayOfKeys.forEach((key) => console.log(key, typeof object[key]));
}

listProperties(person);
