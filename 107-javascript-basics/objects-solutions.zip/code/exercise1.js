const course = {
  title: 'Web Entwicklung',
  description: 'asdfasdfsadf',
  students: ['Johannes', 'Regina', 'Marco'],
  topics: ['HTML', 'CSS', 'JS'],
  trainer: ['Martin', 'Pius', 'Daniel'],
  printCourseInformation() {
    console.log(this.title, this.description, this.students, this.topics, this.trainers);
  },
  enrollStudent(name) {
    this.students.push(name);
    console.log(this.students);
  },
};

course.printCourseInformation();
