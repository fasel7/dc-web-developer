const course = {
  title: 'Web Entwickler',
  description: 'Alles was man über Web Entwicklung wissen muss.',
  trainer: ['Martin', 'Pius', 'Daniel'],
  topics: [
    {
      name: 'HTML',
      description: 'Alles über HTML',
      units: 20,
      trainer: 'Martin',
    },
    {
      name: 'CSS',
      description: 'Alles über CSS',
      units: 40,
      trainer: 'Pius',
    },
    {
      name: 'JS',
      description: 'Alles über JS',
      units: 80,
      trainer: 'Daniel',
    },
  ],
  students: [],
  addCourse(name, description, units, trainer) {
    this.topics.push({
      name,
      description,
      units,
      trainer,
    });
  },
  enrollStudent() {
    if (this.students.length >= 5) {
      alert('Der Kurs ist bereits voll.');
      return;
    }

    const name = prompt('Bitte geben Sie den Namen des Stundenten ein');

    if (name) {
      this.students.push(name);
      console.log(name, ' wurde hinzugefügt.');
    } else {
      alert('Gib einen Namen ein!');
    }
  },
  print() {
    for (let key in this) {
      const value = this[key];
      if (typeof value !== 'function') {
        console.log(key, value);
      }
    }
  },
  getTotalUnits() {
    let total = 0;

    for (let i in this.topics) {
      total += this.topics[i].units;
    }

    return total;
  },
};

course.enrollStudent();
